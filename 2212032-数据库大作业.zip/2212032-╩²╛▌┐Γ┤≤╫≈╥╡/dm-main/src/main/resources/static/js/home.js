/**
 * 首页
 */
function homeNav() {
    navSelected('#homeNavItem');
    contentHeadShow('.homeHead');
    clearContentTable();
    initHome();
}

/**
 * 首页导航初始化
 */
function initHome() {
}